var menu_btn = document.getElementById("menuBtn");
var circleOne = document.getElementById("circleOne");
var circleTwo = document.getElementById("circleTwo");
var search = document.getElementById("search");
var diameterValue = (Math.sqrt(Math.pow(320, 2) + Math.pow(568, 2)) * 2);
var cGroup = document.querySelectorAll('.c1');
var lineOne = document.getElementById('lineOne');
var lineTwo = document.getElementById('lineTwo');
var lineThree = document.getElementById('lineThree');
var tl = new TimelineMax({paused:true});
function init() {
cir_init();
headerAnimation();
}
init();
menuBtn.addEventListener('click', function() {
      menu_btn.classList.toggle('open');
    if (menu_btn.classList.contains('open')) {
            tl.play();
    } else {
        tl.reverse();
    }
});
search.addEventListener('click', function() {
  TweenMax.to(circleTwo, 0.6, {
      scaleX:diameterValue / 78,
      scaleY:diameterValue / 78,
      opacity:1
  });
});
for (var i = 0; i < cGroup.length; i++) {
    cGroup[i].addEventListener('click', function(){
       tl.reverse();
    });
};
function cir_init() {
    TweenMax.to(circleOne, 0.5, {
        width: diameterValue + 'px',
        height: diameterValue + 'px',
        top: -diameterValue / 2 + 'px',
        left: -diameterValue / 2 + 'px',
        scaleX: 0,
        scaleY: 0,
        opacity:0,
        zIndex:1
    });

}
function headerAnimation() {
  tl.to(lineThree,0.1,{width:0}).to(lineOne,0.1,{rotation:45,y:0}).to(lineTwo,0.1,{rotation:-45,y:-10}).to(circleOne, 0.5, {
      scaleX: 1,
      scaleY: 1,
      opacity:1,
  }).staggerTo(cGroup,0.4,{scale:1,opacity:1,ease:Bounce.easeOut},0.1);
}
